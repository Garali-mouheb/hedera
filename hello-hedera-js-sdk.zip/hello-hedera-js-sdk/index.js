const { 
  Client, 
  PrivateKey, 
  AccountId, 
  TokenCreateTransaction, 
  TokenType, 
  TokenSupplyType, 
  TokenMintTransaction, 
  TokenAssociateTransaction, 
  TokenTransferTransaction,
  FileCreateTransaction,
  Hbar
} = require("@hashgraph/sdk");

// Assurez-vous que ces informations correspondent à votre compte de test et à votre clé privée.
// Les informations d'identification que vous avez fournies
const operatorPrivateKey = PrivateKey.fromString("3030020100300706052b8104000a04220420b64509496d7f9be5a30b3d24ea2a48e83966936d0291e3e896fdf8f1e810c88f");
const operatorAccountId = AccountId.fromString("0.0.7713970");
const recipientAccountId = AccountId.fromString("0.0.7713970"); // ID du destinataire, dans ce cas c'est le même que l'opérateur


const client = Client.forTestnet();
client.setOperator(operatorAccountId, operatorPrivateKey);

async function main() {
  // Création de fichier pour les métadonnées
  const fileCreateTxResponse = await new FileCreateTransaction()
      .setContents(Buffer.from(JSON.stringify({
          name: "Villa Oasis",
          description: "Une superbe villa avec vue sur la mer",
          pricePerNight: "350",
          numberOfElements: 5,
          surface: "500m²",
          amplitude: "3 étages"
      })))
      .setMaxTransactionFee(new Hbar(20))
      .execute(client);

  const fileCreateReceipt = await fileCreateTxResponse.getReceipt(client);
  const fileID = fileCreateReceipt.fileId;

  // Création du NFT
  const tokenCreateResponse = await new TokenCreateTransaction()
      .setTokenType(TokenType.NonFungibleUnique)
      .setTokenName("Villa Oasis NFT")
      .setTokenSymbol("VONFT")
      .setSupplyType(TokenSupplyType.Finite)
      .setMaxSupply(1)
      .setTreasuryAccountId(operatorAccountId)
      .setAdminKey(operatorPrivateKey)
      .setSupplyKey(operatorPrivateKey) // Ajoutez une clé d'approvisionnement
      .setMaxTransactionFee(new Hbar(20))
      .execute(client);

  const tokenCreateReceipt = await tokenCreateResponse.getReceipt(client);
  const tokenId = tokenCreateReceipt.tokenId;

  // Émission (Mint) du NFT
  
  const mintResponse = await new TokenMintTransaction()
      .setTokenId(tokenId)
      .addMetadata(Buffer.from(JSON.stringify({
          metadataFileId: fileID.toString()
      })))
      .setMaxTransactionFee(new Hbar(20))
      .execute(client);

  const mintReceipt = await mintResponse.getReceipt(client);
  const serialNumber = mintReceipt.serials[0].toInt();

  // Association du NFT avec le compte destinataire
     await new TokenAssociateTransaction()
      .setAccountId(recipientAccountId)
      .setTokenIds([tokenId])
      .execute(client);
  /*
  // Transfert du NFT au compte destinataire
  await new TokenTransferTransaction()
      .addNftTransfer(tokenId, serialNumber, operatorAccountId, recipientAccountId)
      .execute(client);

  console.log(`Le NFT avec l'ID de fichier ${fileID} a été créé et transféré au compte ${recipientAccountId}`);
}*/

main().catch((error) => {
  console.error("Une erreur s'est produite lors de la création / transfert du NFT: ", error);
  process.exit(1);
});